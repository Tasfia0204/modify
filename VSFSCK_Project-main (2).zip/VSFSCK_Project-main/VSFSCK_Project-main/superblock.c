#include "vsfs.h"
#include <stdio.h>


void read_superblock(FILE *fp, Superblock *sb) {
    fseek(fp, 0, SEEK_SET);
    fread(sb, sizeof(Superblock), 1, fp);
}

void validate_superblock(Superblock *sb) {
    if (sb->block_size != BLOCK_SIZE) {
        printf("ERROR: Incorrect block size in superblock\n");
    }

    if (sb->total_blocks != TOTAL_BLOCKS) {
        printf("ERROR: Incorrect total blocks in superblock\n");
    }

    if (sb->inode_size != INODE_SIZE) {
        printf("ERROR: Incorrect inode size in superblock\n");
    }

    if (sb->inode_count > INODE_COUNT) {
        printf("ERROR: Inode count exceeds the limit\n");
    }
}
